To run flask application

> $env:FLASK_ENV = "development"
> $env:FLASK_APP = "app.py"
> flask run


To activate environment

.\env\Scripts\activate.ps1


http://127.0.0.1:5000 